.class Lcom/appid/MainActivity$webViewClient;
.super Landroid/webkit/WebViewClient;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/appid/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "webViewClient"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/appid/MainActivity;


# direct methods
.method private constructor <init>(Lcom/appid/MainActivity;)V
    .locals 0

    .line 42
    iput-object p1, p0, Lcom/appid/MainActivity$webViewClient;->this$0:Lcom/appid/MainActivity;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/appid/MainActivity;Lcom/appid/MainActivity$1;)V
    .locals 0

    .line 42
    invoke-direct {p0, p1}, Lcom/appid/MainActivity$webViewClient;-><init>(Lcom/appid/MainActivity;)V

    return-void
.end method


# virtual methods
.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 0

    .line 44
    invoke-virtual {p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    const/4 p1, 0x1

    return p1
.end method
