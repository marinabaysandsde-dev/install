.class public final Lcom/appid/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/appid/R$styleable;,
        Lcom/appid/R$style;,
        Lcom/appid/R$string;,
        Lcom/appid/R$mipmap;,
        Lcom/appid/R$layout;,
        Lcom/appid/R$integer;,
        Lcom/appid/R$id;,
        Lcom/appid/R$drawable;,
        Lcom/appid/R$dimen;,
        Lcom/appid/R$color;,
        Lcom/appid/R$bool;,
        Lcom/appid/R$attr;,
        Lcom/appid/R$anim;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
