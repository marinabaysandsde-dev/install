.class public Lcom/appid/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/appid/MainActivity$MyWebViewDownLoadListener;,
        Lcom/appid/MainActivity$webViewClient;
    }
.end annotation


# instance fields
.field private webview:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 32
    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 19
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f09001b

    .line 20
    invoke-virtual {p0, p1}, Lcom/appid/MainActivity;->setContentView(I)V

    const p1, 0x7f07008b

    .line 21
    invoke-virtual {p0, p1}, Lcom/appid/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/webkit/WebView;

    iput-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    .line 22
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    const/4 v0, -0x1

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 23
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    const/4 v0, 0x1

    .line 24
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 25
    invoke-virtual {p1, v0}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 26
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    const-string v0, "[url]"

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 27
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    new-instance v0, Lcom/appid/MainActivity$webViewClient;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/appid/MainActivity$webViewClient;-><init>(Lcom/appid/MainActivity;Lcom/appid/MainActivity$1;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 28
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    new-instance v0, Lcom/appid/MainActivity$MyWebViewDownLoadListener;

    invoke-direct {v0, p0, v1}, Lcom/appid/MainActivity$MyWebViewDownLoadListener;-><init>(Lcom/appid/MainActivity;Lcom/appid/MainActivity$1;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 1

    const/4 v0, 0x4

    if-ne p1, v0, :cond_0

    .line 36
    iget-object v0, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 37
    iget-object p1, p0, Lcom/appid/MainActivity;->webview:Landroid/webkit/WebView;

    invoke-virtual {p1}, Landroid/webkit/WebView;->goBack()V

    const/4 p1, 0x1

    return p1

    .line 40
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method
